<html>
<head> 
     <title> TutorList </title>
</head>
       <body style="background-color:white;">
	
	        <table align="center">
					<tr>
						<td> <span style="color: green;" ><h1> TutorList <h1> </span> </td>
					</tr>
	 
		  	
		    </table> 
			<fieldset style="width:900px;border:solid 2px">
		
	
		
			 <img src="Evan.jpg"; style="padding-right:10px" height="140px" width="140px" font-size=2.5e > <br> 
			 <span> <b> Evan Sarwar </b> <br><b>Tuition-ID:</b>#H-0034 <br><b>  Qualification:</b> BSC in CSE  </span> <br> 
			 <span> <b>Areas:</b> Azimpur, Bangla Motor, Dhaka University Area, Dhanmondi, Easkaton, Elephant Road, Farmgate,<br>
			 Green Road, Hatirjheel, Indira Road, Kalabagan, Moghbazar, Monipuripara, New Eskaton Road,<br>
			 New market, Panthapath, Shabagh, Sukrabad, Tejkunipara, Zigatola</span><br>
             <span> <b>Teaching:</b> All, Bangla, Biology, Chemistry, English, General Math, General Science, Higher Maths, Physics</span><br>
             <span> <b>Experience:</b> 2 years.</span>
			 
			 
	      <span style="padding-left:600px"><a target="_blank" href="details.php" class="btn btn-danger" > Details</a>
            <a target="_blank" href="contact.php">contact </a></span>
		
			</fieldset>
			
			<br> 
			
			
			<fieldset style="width:900px;border:solid 2px">
		
	
		
			 <img src="s.jpg"; style="padding-right:10px" height="140px" width="140px" font-size=2.5e > <br> 
			 <span> <b> Tasnuva akter Tonni </b> <br><b>Tuition-ID:</b>#F-0123 <br><b>  Qualification:</b>Undergrad student   </span> <br> 
			 <span> <b>Areas:</b> Cantonment, Cantonment (Matikata), Ibrahimpur, Kafrul, Kuril, Mirpur -10, Mirpur -14</span><br>
             <span> <b>Teaching:</b> Biology, Chemistry, Higher Maths, Physics</span><br>
             <span> <b>Experience:</b> 3 years.</span>
			 
			 
	      <span style="padding-left:600px"><a target="_blank" href="Details1.php" > Details</a>
            <a target="_blank" href="contact.php">contact </a></span>
			</fieldset>
		
			
			
			
			<br> 
			
			
			<fieldset style="width:900px;border:solid 2px">
		
	
		
			 <img src="h.jpg"; style="padding-right:10px" height="140px" width="140px" font-size=2.5e > <br> 
			 <span> <b> Abdullah Al Noman  </b> <br><b>Tuition-ID:</b>#W-0976 <br><b>  Qualification:</b> BBA  </span> <br> 
			 <span> <b>Areas:</b>Banani, Banani DOHS </span><br>
             <span> <b>Teaching:</b> All, Bangla, English, General Math, General Science, Islamic Studies</span><br>
             <span> <b>Experience:</b> 1 years.</span>
			 
			 
	      <span style="padding-left:600px"><a target="_blank" href="Details2.php" class="btn btn-danger" > Details</a>
            <a target="_blank" href="contact.php">contact </a></span>
			</fieldset>
			
		
				<br> 
			
			
			<fieldset style="width:900px;border:solid 2px">
		
	
		
			 <img src="p.jpg"; style="padding-right:10px" height="140px" width="140px" font-size=2.5e > <br> 
			 <span> <b> Afrina Mim </b> <br><b>Tuition-ID:</b>#G-03476 <br><b>  Qualification:</b>KUET-cse engineer   </span> <br> 
			 <span> <b>Areas:</b>Bashundara residential area  </span><br>
             <span> <b>Teaching:</b> Physics, Chemistry , biology </span><br>
             <span> <b>Experience:</b> 4 years.</span>
			 
			 
	      <span style="padding-left:600px"><a target="_blank" href="Details3.php" class="btn btn-danger" > Details</a>
            <a target="_blank" href="contact.php">contact </a></span>
			</fieldset>
		

	
		
			
	 
		
	
	  </body> 

</html>